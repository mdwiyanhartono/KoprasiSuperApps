package dwiyanhartono.com.loankoprasi;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class TagihanMF extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tagihanmf);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}