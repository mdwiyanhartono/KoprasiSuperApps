package dwiyanhartono.com.loankoprasi.Holder;

import android.view.View;

public interface ItemClickListner {
    void onItemClick(View v, int pos);
}
