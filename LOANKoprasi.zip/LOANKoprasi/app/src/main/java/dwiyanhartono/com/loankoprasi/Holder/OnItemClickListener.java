package dwiyanhartono.com.loankoprasi.Holder;

public interface OnItemClickListener {
}
